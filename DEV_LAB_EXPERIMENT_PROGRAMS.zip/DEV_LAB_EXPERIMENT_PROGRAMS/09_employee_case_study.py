import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from pathlib import Path

path = Path("employees.csv")
if not path.exists():
    raise FileNotFoundError("Place employees.csv in this folder before running this experiment.")

df = pd.read_csv(path)
print(df.head())
print("Shape:", df.shape)
print(df.describe(include="all"))
df.info()
print("Unique values:\n", df.nunique())

if "Start Date" in df.columns:
    df["Start Date"] = pd.to_datetime(df["Start Date"], errors="coerce")
if "Gender" in df.columns:
    df["Gender"] = df["Gender"].fillna("No Gender")
print("Missing values:\n", df.isnull().sum())

if "Salary" in df.columns:
    sns.histplot(data=df, x="Salary")
    plt.title("Salary Distribution")
    plt.tight_layout()
    plt.show()

if {"Salary", "Team"}.issubset(df.columns):
    sns.boxplot(data=df, x="Salary", y="Team")
    plt.tight_layout()
    plt.show()

if {"Salary", "Team", "Gender", "Bonus %"}.issubset(df.columns):
    sns.scatterplot(data=df, x="Salary", y="Team", hue="Gender", size="Bonus %")
    plt.legend(bbox_to_anchor=(1, 1), loc="upper left")
    plt.tight_layout()
    plt.show()
