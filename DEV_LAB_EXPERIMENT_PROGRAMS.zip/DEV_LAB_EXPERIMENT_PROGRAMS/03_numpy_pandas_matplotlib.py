import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# NumPy arrays
arr = np.array([1, 2, 3, 4, 5])
print("Array:", arr)
print("Mean:", np.mean(arr))
print("Sum:", np.sum(arr))
print("Square root:", np.sqrt(arr))
print("First element:", arr[0])
print("Sub-array:", arr[1:4])
print("Combined:", np.concatenate([arr, arr[1:4]]))

# Pandas DataFrame
data = {
    "Name": ["Alice", "Bob", "Charlie", "David", "Emily"],
    "Age": [25, 30, 35, 28, 22],
    "City": ["New York", "Los Angeles", "Chicago", "Houston", "Miami"]
}
df = pd.DataFrame(data)
df["Salary"] = [50000, 60000, 75000, 48000, 55000]
print("\nDataFrame:\n", df)
print("\nPeople older than 30:\n", df[df["Age"] > 30])
print("\nSorted by age:\n", df.sort_values("Age", ascending=False))
print("\nAverage age:", df["Age"].mean())
print("\nAverage salary by city:\n", df.groupby("City")["Salary"].mean())
df.to_csv("output.csv", index=False)
print("\nCSV saved as output.csv")

# Matplotlib line plot
x = np.linspace(0, 10, 100)
y = np.sin(x)
plt.plot(x, y, label="Sine Wave")
plt.title("Sine Wave Plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.legend()
plt.grid(True)
plt.show()
