DATA ANALYSIS AND VISUALIZATION LAB - SEPARATE EXPERIMENT PROGRAMS
Each experiment is saved in its own file in this single folder.

EX 1: 01_installation_guide.txt (installation steps; no program in source manual)
EX 2: 02_email_eda.py
EX 3: 03_numpy_pandas_matplotlib.py
EX 4: 04_r_data_filters.R (run in RStudio or R)
EX 5: 05_wine_quality_eda.py
EX 6: 06_time_series_visualization.py
EX 7: 07_map_data_analysis.py
EX 8: 08_cartographic_visualization.py
EX 9: 09_employee_case_study.py
EX 10: 10_realtime_dashboard.py

INSTALL PYTHON PACKAGES:
python -m pip install -r requirements.txt

RUN:
python 02_email_eda.py
python 03_numpy_pandas_matplotlib.py
...and so on.

EXTERNAL DATA NEEDED:
- Experiment 5: winequality-red.csv (UCI Wine Quality red dataset; semicolon-separated)
- Experiment 9: employees.csv with columns used by the program, such as Salary, Team, Gender, Bonus %, Start Date.
Experiment 2 and 7 include small sample CSV files so they can run immediately.
Experiment 6 uses built-in sample time-series data unless time_series.csv is supplied.
Experiment 8 needs internet access to load the Natural Earth world boundary layer; if unavailable, it plots the city points only.
Experiment 1 is an installation procedure in the supplied manual, not a coding task.
