import pandas as pd
from bokeh.io import output_file, show
from bokeh.models import ColumnDataSource, HoverTool
from bokeh.plotting import figure
import folium

# geographic.csv must contain Longitude, Latitude and Info columns.
data = pd.read_csv("geographic.csv")
required = {"Longitude", "Latitude", "Info"}
if not required.issubset(data.columns):
    raise ValueError(f"geographic.csv must contain columns: {sorted(required)}")

source = ColumnDataSource(data)
p = figure(width=800, height=400, title="Geographic Data with Hover",
           tools="pan,wheel_zoom,reset,save")
p.circle(x="Longitude", y="Latitude", size=10, source=source, color="orange")
p.add_tools(HoverTool(tooltips=[
    ("Info", "@Info"), ("Latitude", "@Latitude"), ("Longitude", "@Longitude")
]))
output_file("bokeh_geographic_plot.html")
show(p)

center = [data["Latitude"].mean(), data["Longitude"].mean()]
m = folium.Map(location=center, zoom_start=5)
for _, row in data.iterrows():
    folium.Marker(
        location=[row["Latitude"], row["Longitude"]],
        popup=str(row["Info"])
    ).add_to(m)
m.save("map.html")
print("Created bokeh_geographic_plot.html and map.html")
