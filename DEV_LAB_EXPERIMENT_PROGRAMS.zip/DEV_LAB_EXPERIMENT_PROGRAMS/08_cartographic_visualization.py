import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.geometry import Point

# Create a GeoDataFrame from the sample city coordinates in the lab record.
df = pd.DataFrame({
    "city": ["Berlin", "Paris", "Munich"],
    "latitude": [52.518611, 48.856667, 48.137222],
    "longitude": [13.408333, 2.351667, 11.575556]
})
gdf = gpd.GeoDataFrame(
    df.drop(columns=["latitude", "longitude"]),
    geometry=[Point(xy) for xy in zip(df.longitude, df.latitude)],
    crs="EPSG:4326"
)
print(gdf)

# Plot city points. A world boundary layer is optional and downloaded from Natural Earth.
try:
    world_url = "https://naturalearth.github.io/natural-earth-geojson/110m_cultural/ne_110m_admin_0_countries.geojson"
    world = gpd.read_file(world_url)
    ax = world.plot(color="white", edgecolor="black", figsize=(10, 6))
    gdf.to_crs(world.crs).plot(ax=ax, marker="o", color="red", markersize=25)
    plt.title("Cartographic Visualization of Selected Cities")
except Exception as exc:
    print("Could not load world boundary layer:", exc)
    gdf.plot(figsize=(8, 6), marker="o", color="red")
    plt.title("Selected City Locations (points only)")
plt.tight_layout()
plt.show()
