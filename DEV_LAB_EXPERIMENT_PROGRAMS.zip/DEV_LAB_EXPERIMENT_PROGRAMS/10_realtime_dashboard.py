import random
import time
from collections import deque

import dash
from dash import dcc, html, Input, Output
import plotly.graph_objs as go

app = dash.Dash(__name__)
x_values = deque(maxlen=20)
y_values = deque(maxlen=20)
x_values.append(time.time())
y_values.append(random.randint(0, 100))

app.layout = html.Div([
    html.H2("Simple Real-Time Dashboard"),
    dcc.Graph(id="live-graph", animate=True),
    dcc.Interval(id="graph-update", interval=1000, n_intervals=0)
])

@app.callback(Output("live-graph", "figure"),
              Input("graph-update", "n_intervals"))
def update_graph(_):
    x_values.append(time.time())
    y_values.append(random.randint(0, 100))
    fig = go.Figure(
        data=[go.Scatter(x=list(x_values), y=list(y_values),
                         mode="lines+markers")]
    )
    fig.update_layout(
        title="Live Random Data",
        xaxis_title="Time",
        yaxis_title="Random Value",
        margin=dict(l=40, r=40, t=40, b=40)
    )
    return fig

if __name__ == "__main__":
    app.run(debug=True, port=8050)
