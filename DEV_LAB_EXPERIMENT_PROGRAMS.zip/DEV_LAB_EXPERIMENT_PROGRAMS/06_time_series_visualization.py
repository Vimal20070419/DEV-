import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# Uses monthly sample data if a local time_series.csv is not present.
path = Path("time_series.csv")
if path.exists():
    series = pd.read_csv(path, index_col=0, parse_dates=True)
    values = series.select_dtypes(include="number").iloc[:, 0]
else:
    dates = pd.date_range("2024-01-01", periods=24, freq="MS")
    values = pd.Series(
        [120, 128, 125, 135, 142, 139, 150, 155, 153, 162, 170, 168,
         175, 180, 178, 188, 195, 192, 205, 210, 208, 218, 225, 222],
        index=dates, name="Value"
    )

print(values.head())
values.plot(title="Time Series Line Plot", xlabel="Date", ylabel="Value")
plt.tight_layout()
plt.show()

values.plot(style="-.", title="Time Series Line Plot (Dash-Dot)")
plt.tight_layout()
plt.show()

values.hist()
plt.title("Time Series Histogram")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

values.plot(kind="kde", title="Time Series Density Plot")
plt.xlabel("Value")
plt.tight_layout()
plt.show()
