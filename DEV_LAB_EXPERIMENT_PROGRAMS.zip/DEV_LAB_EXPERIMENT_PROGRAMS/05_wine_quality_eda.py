import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

# Place winequality-red.csv in this folder. The UCI dataset uses ";" separators.
path = Path("winequality-red.csv")
if not path.exists():
    raise FileNotFoundError(
        "Download the UCI Wine Quality red dataset and save it as "
        "'winequality-red.csv' in this folder. Use semicolon-separated CSV."
    )

data = pd.read_csv(path, sep=";")
print(data.head())
print(data.info())
print(data.describe())

sns.countplot(data=data, x="quality")
plt.title("Wine Quality Dataset")
plt.tight_layout()
plt.show()

features = ["alcohol", "volatile acidity", "citric acid", "residual sugar"]
for feature in features:
    plt.figure(figsize=(8, 5))
    sns.boxplot(data=data, x="quality", y=feature)
    plt.title(f"{feature} by Wine Quality")
    plt.tight_layout()
    plt.show()

sns.pairplot(data, vars=features, hue="quality", diag_kind="hist")
plt.suptitle("Pair Plot of Selected Features", y=1.02)
plt.show()

plt.figure(figsize=(10, 8))
sns.heatmap(data.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()

for feature in features:
    plt.figure(figsize=(6, 4))
    sns.histplot(data[feature], kde=True, bins=20)
    plt.title(f"Distribution of {feature}")
    plt.tight_layout()
    plt.show()
