# Experiment 4: Variable and row filters in R
set.seed(123)
data <- data.frame(
  ID = 1:10,
  Age = sample(18:60, 10, replace = TRUE),
  Gender = sample(c("Male", "Female"), 10, replace = TRUE),
  Score = sample(1:100, 10)
)
print(data)

# Filter rows using one condition
filtered_data <- data[data$Age > 30, ]
print(filtered_data)

# Filter rows using multiple conditions
filtered_male <- data[data$Age > 30 & data$Gender == "Male", ]
print(filtered_male)

# Remove duplicate rows and rows with missing values
cleaned_data <- unique(data[, c("ID", "Age", "Gender", "Score")])
cleaned_data <- na.omit(cleaned_data)
print(cleaned_data)

# Visualizations (install ggplot2 once with install.packages("ggplot2"))
if (requireNamespace("ggplot2", quietly = TRUE)) {
  library(ggplot2)
  print(ggplot(cleaned_data, aes(x = Age, y = Score, color = Gender)) +
          geom_point() + labs(title = "Age vs Score", x = "Age", y = "Score"))
  print(ggplot(cleaned_data, aes(x = Age)) +
          geom_histogram(binwidth = 5, fill = "blue", alpha = 0.5) +
          labs(title = "Age Histogram", x = "Age", y = "Frequency"))
  print(ggplot(cleaned_data, aes(x = Gender)) +
          geom_bar(fill = "green", alpha = 0.7) +
          labs(title = "Gender Distribution", x = "Gender", y = "Count"))
} else {
  message('Install ggplot2 using install.packages("ggplot2") to display plots.')
}
