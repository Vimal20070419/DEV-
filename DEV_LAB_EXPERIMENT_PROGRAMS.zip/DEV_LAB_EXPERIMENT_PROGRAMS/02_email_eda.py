import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud

# Uses the supplied sample email_data.csv in this folder.
df = pd.read_csv("email_data.csv")
print(df.info())
print(df.head())
print(df.describe(include="all"))
print("\nMissing values:\n", df.isnull().sum())

if "label" in df.columns:
    sns.countplot(data=df, x="label")
    plt.title("Email Label Distribution")
    plt.tight_layout()
    plt.show()

text_column = "text" if "text" in df.columns else None
if text_column and df[text_column].dropna().any():
    text = " ".join(df[text_column].dropna().astype(str))
    cloud = WordCloud(width=800, height=400, background_color="white").generate(text)
    plt.imshow(cloud, interpolation="bilinear")
    plt.axis("off")
    plt.title("Common Words in Emails")
    plt.show()
